function ridxs = RPeakfromRWave(ecg,rWaveIdx)

    ridxs = rWaveIdx;
    for i = 1:length(rWaveIdx)
        currpoint = rWaveIdx(i);
        while 1
            if currpoint > 1 && currpoint < length(ecg)
                if ecg(currpoint) <= ecg(currpoint+1)
                    currpoint = currpoint +1;
                elseif ecg(currpoint) < ecg(currpoint-1)
                    currpoint = currpoint - 1;
                else
                    ridxs(i) = currpoint;
                    break
                end
            else
                ridxs(i) = currpoint;
                break
            end

        end
    end
%     time = 1:length(ecg);
%     plot(time,ecg);
%     hold on;
%     scatter(time(ridx),ecg(ridx),'c');
%     scatter(time(rWaveIdx),ecg(rWaveIdx),'r');

end