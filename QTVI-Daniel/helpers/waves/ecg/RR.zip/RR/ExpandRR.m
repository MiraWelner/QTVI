function [idxs] = ExpandRR(rr_indexes,sample_rate, max_size,divisor)
    idxs = [rr_indexes(1:end - 1)' rr_indexes(2:end)'];

    idxs(:,1) = idxs(:,1) - round(sample_rate/divisor);
    idxs(:,2) = idxs(:,2) + round(sample_rate/divisor);
    
    idxs(idxs < 1) = 1;
    idxs(idxs > max_size) = max_size;
end

