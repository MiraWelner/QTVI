function [rridx,rramps] = RRsimpleSquared(ecg,minDist)
    ecgSigSq =ecg.^2;
    [rramps,rridx] = findpeaks(ecgSigSq,'MinPeakHeight',mean(ecgSigSq)+std(ecgSigSq)*2,'MinPeakDistance',minDist);
    rridx = rridx';
end